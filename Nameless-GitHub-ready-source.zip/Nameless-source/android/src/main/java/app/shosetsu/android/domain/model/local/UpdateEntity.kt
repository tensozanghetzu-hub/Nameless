package app.shosetsu.android.domain.model.local

import app.shosetsu.android.domain.model.database.DBUpdate

/*
 * This file is part of shosetsu.
 *
 * shosetsu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * shosetsu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with shosetsu.  If not, see <https://www.gnu.org/licenses/>.
 * ====================================================================
 */

/**
 * shosetsu
 * 22 / 04 / 2020
 *
 * @author github.com/doomsdayrs
 *
 * @param chapterID [DBUpdate.chapterID]
 * @param novelID [DBUpdate.novelID]
 * @param time [DBUpdate.time]
 */
data class UpdateEntity(
	val chapterID: Int,
	val novelID: Int,
	val time: Long,
)