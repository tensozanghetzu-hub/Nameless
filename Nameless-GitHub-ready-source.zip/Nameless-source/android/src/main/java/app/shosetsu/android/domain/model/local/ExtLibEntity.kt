package app.shosetsu.android.domain.model.local

import app.shosetsu.android.domain.model.database.DBExtLibEntity
import app.shosetsu.lib.Version

/*
 * This file is part of shosetsu.
 *
 * shosetsu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * shosetsu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with shosetsu.  If not, see <https://www.gnu.org/licenses/>.
 * ====================================================================
 */

/**
 * shosetsu
 * 22 / 04 / 2020
 *
 * @author github.com/doomsdayrs
 * This class represents a library that is installed in system
 *
 * @param scriptName [DBExtLibEntity.scriptName]
 * @param version [DBExtLibEntity.version]
 * @param repoID [DBExtLibEntity.repoID]
 */

data class ExtLibEntity(
	val scriptName: String,
	var version: Version,
	var repoID: Int,
)